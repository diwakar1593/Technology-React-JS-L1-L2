import React from "react";
import AllIssuesPage from "./components/AllIssuesPage";

export default class App extends React.Component {
    render() {
        return (
            <AllIssuesPage />
        );
    }
}